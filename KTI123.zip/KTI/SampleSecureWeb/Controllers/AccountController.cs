using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using SampleSecureWeb.Data;
using SampleSecureWeb.Models;
using SampleSecureWeb.ViewModels;
using System.Threading.Tasks;

namespace SampleSecureWeb.Controllers
{
    public class AccountController : Controller
    {
        private readonly IUser _userData;
        
        // Dependency Injection of IUser
        public AccountController(IUser user)
        {
            _userData = user ?? throw new ArgumentNullException(nameof(user)); // Null check for injected dependency
        }

        // GET: AccountController
        public ActionResult Index()
        {
            return View();
        }

        // Register
        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(RegistrationViewModel registrationViewModel)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    // Hash the password before saving to the database
                    var hashedPassword = HashPassword(registrationViewModel.Password); // Hashing method needed

                    var user = new Models.User
                    {
                        Username = registrationViewModel.Username,
                        Password = hashedPassword, // Use the hashed password
                        RoleName = "contributor"
                    };

                    _userData.Registration(user); // Assuming _userData handles duplicate checks and other validation

                    return RedirectToAction("Index", "Home");
                }
            }
            catch (Exception ex)
            {
                // Log the exception (optional, use a logger)
                ViewBag.Error = "An error occurred during registration: " + ex.Message;
            }

            return View(registrationViewModel); // Return the view with validation errors
        }

        // Login
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<ActionResult> Login(LoginViewModel loginViewModel)
        {
            try
            {
                // Ensure ReturnUrl is set correctly
                loginViewModel.ReturnUrl ??= Url.Content("~/");

                if (ModelState.IsValid)
                {
                    var user = new User
                    {
                        Username = loginViewModel.Username,
                        Password = loginViewModel.Password
                    };

                    // Retrieve the user from the database using _userData
                    var loginUser = _userData.Login(user);

                    if (loginUser == null)
                    {
                        ViewBag.Message = "Invalid login attempt.";
                        return View(loginViewModel);
                    }

                    // Verify password before signing in (assuming hashed passwords are used)
                    if (!VerifyPassword(loginViewModel.Password, loginUser.Password)) // VerifyPassword method needed
                    {
                        ViewBag.Message = "Invalid login credentials.";
                        return View(loginViewModel);
                    }

                    // Create user claims
                    var claims = new List<Claim>
                    {
                        new Claim(ClaimTypes.Name, loginUser.Username),
                        new Claim(ClaimTypes.Role, loginUser.RoleName)
                    };

                    var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                    var principal = new ClaimsPrincipal(identity);

                    // Sign the user in with persistent cookie option
                    await HttpContext.SignInAsync(
                        CookieAuthenticationDefaults.AuthenticationScheme,
                        principal,
                        new AuthenticationProperties
                        {
                            IsPersistent = loginViewModel.RememberLogin
                        });

                    return LocalRedirect(loginViewModel.ReturnUrl); // Use LocalRedirect to prevent open redirect vulnerability
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = "An error occurred during login: " + ex.Message;
            }

            return View(loginViewModel);
        }

        // Helper method to hash passwords (use a secure hashing algorithm)
        private string HashPassword(string password)
        {
            // Implement password hashing (e.g., using SHA-256 or bcrypt)
            return password; // Placeholder, replace with actual hashing logic
        }

        // Helper method to verify hashed password
        private bool VerifyPassword(string enteredPassword, string storedHashedPassword)
        {
            // Implement password verification (compare hashed entered password with stored hashed password)
            return enteredPassword == storedHashedPassword; // Placeholder, replace with actual comparison logic
        }
    }
}

